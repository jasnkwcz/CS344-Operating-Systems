Joshua Sienkiewicz
CS344 - Operating Systems
Project 3 - smallsh

to compile this program, run the following command:
	"gcc --std=gnu99 -o smallsh main.c"

to run smallsh, run the following command:
	"./smallsh"


