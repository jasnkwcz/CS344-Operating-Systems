#include "movie.h"

void buildDir(char *filename);

void processLargest();

void processSmallest();

void makeDirname(char *dirname);
