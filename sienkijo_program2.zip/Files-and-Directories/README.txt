Joshua Sienkiewicz
CS344 - Operating systems
Project 2 - Files and Directories

Create an executable called "movies_by_year" with the following command:
    gcc --std=gnu99 -o movies_by_year *.c

Run the executable with:
    ./movies_by_year

