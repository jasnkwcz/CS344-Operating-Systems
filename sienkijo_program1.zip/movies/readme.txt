Joshua Sienkiewicz
CS344 - Operating Systems
Project 1 - Movies

To compile:
$gcc --std=gnu99 -o movies movie.c main.c 

To run executable:
$./movies <movie-file-name>.csv